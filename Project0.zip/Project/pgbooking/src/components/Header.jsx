import { Link } from 'react-router-dom';
import './Header.css';

function Header() {
  return (
    <header className="header">
      <h1>Welcome to Sunrise PG</h1>
      <nav>
        <ul className="nav-links">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/about">About</Link></li>
          <li><Link to="/contact">Contact Us</Link></li>
          <li><Link to="/preview">Preview Room</Link></li>
        </ul>
      </nav>
      <p className="location">📍 Available in: Delhi, Noida, Faridabad, Ghaziabad, Gurugram</p>
    </header>
  );
}

export default Header;