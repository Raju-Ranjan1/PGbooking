function Footer() {
  return (
    <footer className="footer">
      <p>© 2025 Sunrise PG. All rights reserved.</p>
      <p>For booking and queries, contact: <a href="mailto:pgbooking@sunrise.com">pgbooking@sunrise.com</a></p>
    </footer>
  );
}

export default Footer;