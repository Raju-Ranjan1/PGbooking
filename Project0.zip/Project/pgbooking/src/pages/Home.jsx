import './Home.css';





function Home() {
  const rooms = [
    {
      id: 1,
      name: "Premium Room",
      price: "₹9,000/month",
      area: "Delhi",
      features: ["Wi-Fi", "Laundry", "Meals"],
      image: "/assets/room1.jpg"
    },
    {
      id: 2,
      name: "Standard Room",
      price: "₹7,500/month",
      area: "Noida",
      features: ["Wi-Fi", "Meals"],
      image: "/assets/room2.jpg"
    },
    {
      id: 3,
      name: "Economy Room",
      price: "₹6,000/month",
      area: "Faridabad",
      features: ["Wi-Fi"],
      image: "/assets/room3.jpg"
    },
    {
      id: 4,
      name: "Executive Room",
      price: "₹8,000/month",
      area: "Ghaziabad",
      features: ["Wi-Fi", "Laundry", "Meals"],
      image: "/assets/room4.jpg"
    },
    {
      id: 5,
      name: "Shared Room",
      price: "₹5,000/month",
      area: "Gurugram",
      features: ["Wi-Fi", "Meals"],
      image: "/assets/room5.jpg"
    },
  ];

  return (
    <div className="home-page">
      <h2>Available Rooms</h2>
      <div className="room-list">
        {rooms.map((room) => (
          <div key={room.id} className="room-card">
            <img src={room.image} alt={room.name} />
            <h3>{room.name}</h3>
            <p>{room.price}</p>
            <p>📍 {room.area}</p>
            <p>🛎️ Features: {room.features.join(', ')}</p>
          </div>
        ))}
      </div>
      <footer className="home-footer">
        <p>© 2025 Sunrise PG. All rights reserved.</p>
        <p>For booking and queries, contact: pgbooking@sunrise.com</p>
      </footer>
    </div>
  );
}

export default Home;