import './Contact.css';
import Footer from '../components/Footer';




function Contact() {
  return (
    <div className="contact-page">
      <h2>Contact Us</h2>
      <p>Email: pgbooking@sunrise.com</p>
      <p>Phone: 98765 43210</p>
      <p>Address: Sunrise PG, Nehru Place, Delhi</p>
      <Footer />
    </div>
  );
}

export default Contact;