import { useNavigate } from 'react-router-dom';
import './Preview.css';
import Footer from '../components/Footer';

function Preview() {
  const navigate = useNavigate();

  const previewRooms = [
    {
      id: 1,
      name: "Premium Room",
      price: "₹9,000/month",
      area: "Delhi",
      features: ["Wi-Fi", "Laundry", "Meals"],
      image: "/assets/room1.jpg"
    },
    {
      id: 2,
      name: "Standard Room",
      price: "₹7,500/month",
      area: "Noida",
      features: ["Wi-Fi", "Meals"],
      image: "/assets/room2.jpg"
    },
    {
      id: 3,
      name: "Economy Room",
      price: "₹6,000/month",
      area: "Faridabad",
      features: ["Wi-Fi"],
      image: "/assets/room3.jpg"
    },
    {
      id: 4,
      name: "Executive Room",
      price: "₹8,000/month",
      area: "Ghaziabad",
      features: ["Wi-Fi", "Laundry", "Meals"],
      image: "/assets/room4.jpg"
    },
    {
      id: 5,
      name: "Shared Room",
      price: "₹5,000/month",
      area: "Gurugram",
      features: ["Wi-Fi", "Meals"],
      image: "/assets/room5.jpg"
    },
    {
      id: 6,
      name: "Comfort Room",
      price: "₹8,500/month",
      area: "Noida",
      features: ["Wi-Fi", "Meals"],
      image: "/assets/room6.jpg"
    },
    {
      id: 7,
      name: "Budget Nest",
      price: "₹6,000/month",
      area: "Faridabad",
      features: ["Wi-Fi", "Meals"],
      image: "/assets/room7.jpg"
    },
    {
      id: 8,
      name: "Solo Stay",
      price: "₹6,500/month",
      area: "Gurugram",
      features: ["Wi-Fi"],
      image: "/assets/room8.jpg"
    }



    
  ];

  return ( <>
    <div className="preview-page">
      <h2>Preview Our Rooms</h2>
      <div className="preview-room-list">
        {previewRooms.map((room) => (
          <div key={room.id} className="preview-room-card">
            <img src={room.image} alt={room.name} />
            <h3>{room.name}</h3>
            <p>{room.price}</p>
            <p>📍 {room.area}</p>
            <p>🛎️ Features: {room.features.join(', ')}</p>
            <button onClick={() => navigate('/book')}>Book Now</button>
            
          </div>
        ))}
      </div>
    </div>
    
    <Footer />
    </>
  );
}

export default Preview;
