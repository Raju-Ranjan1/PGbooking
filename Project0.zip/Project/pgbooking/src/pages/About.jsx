import './About.css';
import Footer from '../components/Footer';




function About() {
  return (
    <div className="about-page">
      <h2>About Sunrise PG</h2>
      <p>We offer affordable, comfortable, and secure PG accommodations across Delhi NCR. With modern amenities and prime locations, our goal is to make your living experience hassle-free and homely.</p>
       <Footer />
    </div>
  );
}

export default About;