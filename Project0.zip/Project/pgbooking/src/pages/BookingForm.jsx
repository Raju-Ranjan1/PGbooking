import './BookingForm.css';

function BookingForm() {
  return (
    <form className="booking-form">
      <h2>Booking Form</h2>

      <div className="form-group">
        <label>Name:</label>
        <input type="text" required />
      </div>

      <div className="form-group">
        <label>Mobile No.:</label>
        <input type="tel" required />
      </div>

      <div className="form-group">
        <label>Identity Card Type:</label>
        <select required>
          <option value="">Select</option>
          <option value="PAN">PAN</option>
          <option value="Aadhaar">Aadhaar</option>
        </select>
      </div>

      <div className="form-group">
        <label>Card Number:</label>
        <input type="text" required />
      </div>

      <div className="form-group">
        <label>Select Area:</label>
        <select required>
          <option value="">Select</option>
          <option>Delhi</option>
          <option>Noida</option>
          <option>Faridabad</option>
          <option>Ghaziabad</option>
          <option>Gurugram</option>
        </select>
      </div>

      <button type="submit">Submit Booking</button>
    </form>
  );
}

export default BookingForm;